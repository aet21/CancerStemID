## ----vignette-options, echo=FALSE, message=FALSE, warning=FALSE---------------
require(BiocStyle)

## ----load-data, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE------------
library(CancerStemID);
library(Seurat);
library(SCENT);
library(destiny);
data(mouseESCC);

## ----check-data, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE-----------
print(dim(mouseESCC.o@assays$RNA@data));
range.v <- range(mouseESCC.o@assays$RNA@data);
print(paste("Range of the data is ",range.v[1]," to ",range.v[2],sep=""));
print("Distribution of epithelial cell-types across disease stages:");
print(summary(factor(mouseESCC.o@meta.data$stage)));

## ----load-esoregnet, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE-------
data(netESOPH);
print(dim(netESOPH.m));

## ----estimateTFA, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE----------
tfa.m <- EstTFA(avdataEpiHEID.m,netESOPH.m,norm=c("z"),ncores=4)
print(dim(tfa.m));

## ----dynamicsTFA, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE----------
statDTFA.m <- t(apply(tfa.m,1,function(v){ summary(lm(v ~ mouseESCC.o@meta.data$stageID))$coeff[2,3:4]}))
print(summary(factor(sign(statDTFA.m[which(statDTFA.m[,2] < 0.05/nrow(tfa.m)),1]))));

## ----dynamicsTFA2, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE---------
inf.idx <- which(mouseESCC.o@meta.data$stageID==2);
hydy.idx <- which(mouseESCC.o@meta.data$stageID %in% 3:4);
selCells <- c(inf.idx,hydy.idx);
pheno <- c(rep(1,length(inf.idx)),rep(2,length(hydy.idx)));
statDTFAinfHD.m <- t(apply(tfa.m[,selCells],1,function(v){ summary(lm(v ~ pheno))$coeff[2,3:4]}))
print(summary(factor(sign(statDTFAinfHD.m[which(statDTFAinfHD.m[,2] < 0.05/nrow(tfa.m)),1]))));

## ----computeTFIL, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE----------
pheno <- mouseESCC.o@meta.data$stageID;
pheno[pheno<=2] <- 0;
pheno[pheno %in% c(3,4)] <- 1;
pheno[pheno==5] <- 2;
pheno[pheno==6] <- 3;
tfil.o <- CompTFIL(tfa.m,pheno,thDTFA="BF",thHits=0.05)

## ----barplotTFIL, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE----------
par(mfrow=c(1,3));
nc.v <- summary(factor(pheno));
barplot(summary(factor(tfil.o$tfil[pheno==0]))/nc.v[1],main="Normal cells",xlab="TFIL",ylab="fCells",ylim=c(0,1));
barplot(summary(factor(tfil.o$tfil[hydy.idx]))/nc.v[2],main="Preneoplastic cells",xlab="TFIL",ylab="fCells",ylim=c(0,1));
barplot(summary(factor(tfil.o$tfil[pheno==3]))/nc.v[4],main="Invasive cancer cells",xlab="TFIL",ylab="fCells",ylim=c(0,1));

## ----redefineTFIL, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE---------
tfil.v <- tfil.o$tfil[hydy.idx];
tfil.v[tfil.v>3] <- 3;

## ----computeCRS, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE-----------
crs.o <- CompCancerRisk(tfa.m,pheno,thDTFA="BF");
boxplot(crs.o$risk ~ tfil.v,col=c("skyblue","steelblue","slateblue","blue"),xlab="TFIL",ylab="CRS");
pv <- summary(lm(crs.o$risk ~ tfil.v))$coeff[2,4];
text(x=2.5,y=0.2,paste("P=",signif(pv,2),sep=""),font=2);

## ----plottingDMAP, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE---------
par(mfrow=c(1,2));
par(mar=c(1,1,1,1));
PlotDMAP(crs.o,type="DPT");
PlotDMAP(crs.o,type="Stage",stage=pheno,col=c("darkgreen","slateblue","magenta","brown"));

## ----checkCRStip, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE----------
boxplot(crs.o$riskTip ~ tfil.v,col=c("skyblue","steelblue","slateblue","blue"),xlab="TFIL",ylab="CRS[tips]");
pv <- summary(lm(crs.o$riskTip ~ tfil.v))$coeff[2,4];
text(x=2.5,y=0.6,paste("P=",signif(pv,2),sep=""),font=2);

## ----evalCCAT, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE-------------
data(net13Jun12);
ccatEpi.v <- CompCCAT(avdataEpiHEID.m,ppiA=net13Jun12.m);

## ----boxplotCCAT, eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE----------
boxplot(ccatEpi.v[hydy.idx] ~ tfil.v, xlab = "TFIL", ylab = "Stemness[CCAT]",col=c("skyblue","steelblue","slateblue","blue"));
pv <- summary(lm(ccatEpi.v[hydy.idx] ~ tfil.v))$coeff[2,4];
text(x=2.5,y=0.25,paste("P=",signif(pv,2),sep=""),font=2);

## ----sessionInfo, echo=T------------------------------------------------------
sessionInfo()

